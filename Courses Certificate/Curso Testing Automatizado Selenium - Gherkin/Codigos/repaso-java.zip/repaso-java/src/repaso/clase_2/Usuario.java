package repaso.clase_2;

public class Usuario {

    //Atributos
    private String nombre;
    String email;

    //Metodos
    //Metodo constructor
    public Usuario(String nombre, String email) {
        this.nombre = nombre;
        this.email = email;
    }

    // Otros metodos...
    public void mostrarDatos() {
        System.out.println("Nombre: " + this.nombre);
        System.out.println("Email: " + this.email);
    }

    // Metodos accesores/modificadores
    // get -> Consultar
    // set -> modificar
    public String getNombre(){
        return this.nombre;
    }

    public void setNombre(String nombreNuevo){
        nombre = nombreNuevo;
    }
}
