package repaso.clase_2;

import java.sql.SQLOutput;
import java.util.ArrayList;
import java.util.List;

public class Tienda {

    public static void main(String[] args) {
        //EJERCICIO 1
        Producto p1 = new Producto("Arroz", 100);
        p1.mostrar();
        System.out.println("Aplicamos un descuento del 10%");
        p1.aplicarDescuento(10);
        p1.mostrar();
        System.out.println("--------- ******** -----------");

        //EJERCICIO 2
        List<Producto> productos = new ArrayList<>();
        productos.add(
                new Producto("Mouse", 50)
        );
        productos.add(p1);
        productos.add(new Producto("Monitor", 300.10));

        System.out.println("PRODUCTOS CARGADOS");
        //TipoDato nombreVariable : Lista
        for(Producto p : productos){
            p.mostrar();
        }

        System.out.println("PRODUCTOS MAYOR A 100");
        //Visualizar aquellos productos que su valor es mayor a 100
        for(Producto p : productos){
            if(p.getPrecio() > 100) {
                p.mostrar();
            }
        }

        System.out.println("APLICANDO DESCUENTO...");
        productos.forEach(
                p -> p.aplicarDescuento(10)
        );
        for(Producto p : productos){
            p.mostrar();
        }
    }
}
