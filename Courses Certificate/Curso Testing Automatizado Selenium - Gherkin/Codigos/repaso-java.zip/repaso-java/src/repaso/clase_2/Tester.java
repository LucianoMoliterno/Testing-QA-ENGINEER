package repaso.clase_2;

public class Tester extends Empleado{
    public void trabajar(){
        System.out.println("Tester ejecutando pruebas");
    }
}
