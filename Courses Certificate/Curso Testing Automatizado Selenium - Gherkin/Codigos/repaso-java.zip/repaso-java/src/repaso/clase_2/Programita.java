package repaso.clase_2;

public class Programita {

    public static void main(String[] args) {
        Usuario x = new Usuario("Nelson", "nelson@gmail.com");
        Usuario y = new Usuario("Fabian", "ftravella@example.org");

        x.mostrarDatos();
        y.mostrarDatos();
        System.out.println("-----------------------------------------------");
        // x.nombre = "PEPE";
        x.setNombre("PEPE");
        x.mostrarDatos();
    }
}
