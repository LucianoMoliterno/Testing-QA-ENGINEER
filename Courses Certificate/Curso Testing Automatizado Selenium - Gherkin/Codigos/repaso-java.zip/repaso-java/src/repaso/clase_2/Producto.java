package repaso.clase_2;

public class Producto {
    private String nombre;
    private double precio;

    public Producto(String nombre, double precio){
        if(precio < 0) {
            //System.out.println("El precio no puede ser negativo");
            throw new IllegalArgumentException("El precio no puede ser negativo");
        }

        this.nombre = nombre;
        this.precio = precio;
    }

    public Producto(String nombre){
        this.nombre = nombre;
        this.precio = -1.5;
    }

    public void mostrar(){
        System.out.println("Producto: " + this.nombre + " - Precio: " + this.precio);
    }

    public void aplicarDescuento(double porcentaje){

        double factor = 1 - (porcentaje / 100.0);
        this.precio = Math.round((this.precio * factor) * 100.0) / 100.0; //redondeo a 2 decimales
    }

    public double getPrecio(){
        return this.precio;
    }
}
