package repaso.clase_2;

public class Empleado {


    public void trabajar(){
        System.out.println("Empleado trabajando....");
    }

    public void horario(){
        System.out.println("EL HORARIO ES: ");
    }
}
