package repaso.clase_2;

public class Empresita {

    public static void main(String[] args) {
        Empleado e1 = new Tester();
        e1.trabajar();
        e1.horario();

        Empleado e2 = new Empleado();
        e2.trabajar();
    }
}
