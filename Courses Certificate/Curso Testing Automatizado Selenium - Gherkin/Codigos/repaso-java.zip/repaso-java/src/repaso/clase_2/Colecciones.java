package repaso.clase_2;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Colecciones {

    public static void main(String[] args) {
        List<String> nombres = new ArrayList();
        nombres.add("Nelson");
        nombres.add("PEPE");
        nombres.add("Kora");
        //nombres.add(123123);
        //nombres.add(true);

        //Foreach
        for (String x : nombres){
            System.out.println("VALOR: " + x);
        }
        System.out.println("---------------------");
        for (int i = 0; i < nombres.size(); i = i + 2) {
            System.out.println("VALOR: " + nombres.get(i));
        }
        System.out.println("---------------------");

        Map<Integer, String> usuarios = new HashMap<>();
        usuarios.put(1, "Vicky");
        usuarios.put(2, "Fabian");
        System.out.println(usuarios.get(2));
    }
}
