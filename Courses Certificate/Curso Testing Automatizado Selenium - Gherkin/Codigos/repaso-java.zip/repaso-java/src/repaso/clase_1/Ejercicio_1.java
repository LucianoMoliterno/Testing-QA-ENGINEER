package repaso.clase_1;

public class Ejercicio_1 {

    public static void main(String[] args) {
        // Ejercicio 1 – Edad y voto: Crear un programa que lea una
        // edad y diga si puede votar.

        int edad = 17;

        if (edad >= 18){
            System.out.println("Puede votar! :)");
        } else {
            System.out.println("No puede votar :(");
        }

        String resultado = (edad >= 18)? "Puede votar!!!! :)" : "No puede votar!!!! :(";
        System.out.println(resultado);
    }
}
