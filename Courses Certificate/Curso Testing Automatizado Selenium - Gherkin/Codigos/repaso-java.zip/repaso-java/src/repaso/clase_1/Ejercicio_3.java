package repaso.clase_1;

public class Ejercicio_3 {

    public static void main(String[] args) {
        //Ejercicio 3 – Validación de contraseña

        String password = "Selenium";

        if(password.length() >= 8
            &&
                password.matches(".*[A-Z].*")
                &&
                    password.matches(".*[0-9].*")
        ){
            System.out.println("Contraseña válida");
        }
        else {
            System.out.println("Contraseña no válida");
        }
    }
}
