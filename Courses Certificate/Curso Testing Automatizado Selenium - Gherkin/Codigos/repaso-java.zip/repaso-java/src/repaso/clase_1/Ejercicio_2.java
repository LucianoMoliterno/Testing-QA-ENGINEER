package repaso.clase_1;

public class Ejercicio_2 {

    public static void main(String[] args) {
        //Ejercicio 2 – Promedio de notas

        double notaUno = 7.5;
        double notaDos = 8;
        double notaTres = 9.8;

        //double promedio = (notaUno + notaDos + notaTres) / 3;

        double promedio = (7.5 + 8 + 9.8) / 3;


        System.out.println("El promedio de las notas es: " + promedio);
    }
}
