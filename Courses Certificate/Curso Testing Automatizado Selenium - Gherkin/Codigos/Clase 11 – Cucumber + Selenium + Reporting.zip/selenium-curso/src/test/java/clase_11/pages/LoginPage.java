package clase_11.pages;

import clase_11.base.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPage extends BasePage {

    //Localizadores
    private By userInput = By.id("user-name");
    private By passInput = By.id("password");
    private By loginBtn = By.id("login-button");
    private By messageError = By.xpath("//h3[@data-test='error']");

    //Constructor
    public LoginPage(WebDriver driver){
        // Heredamos el constructor de la clase
        //Lo llamamos mediante el metodo 'super()'
        super(driver);
    }

    //Acciones
    public void ingresarUsuario(String usuario){
        escribir(this.userInput, usuario);
    }

    public void ingresarPassword(String password){
        escribir(this.passInput, password);
    }

    public void hacerLogin(String usuario, String password){
        escribir(this.userInput, usuario);
        escribir(this.passInput, password);
        click(this.loginBtn);
    }

    public String obtenerMensajeError(){
        return obtenerTexto(this.messageError);
    }
}
