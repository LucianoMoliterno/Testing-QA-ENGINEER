package clase_11.base;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class BasePage {

    // public -> cualquiera tiene acceso
    // private -> solo tiene acceso la misma clase o desde afuera con los metodos get/set
    // protected -> solo tiene accesos las clases que HEREDAN
    protected WebDriver driver;
    protected WebDriverWait wait;

    public BasePage(WebDriver driver){
        this.driver = driver;
        // Creamos una espera que es explicita
        this.wait = new WebDriverWait(
                driver,
                Duration.ofSeconds(10)
        );
    }

    protected WebElement esperarVisible(By locator){
        return wait.until(
                ExpectedConditions.visibilityOfElementLocated(locator)
        );
    }

    protected WebElement esperarClickear(By locator){
        return wait.until(
                ExpectedConditions.elementToBeClickable(locator)
        );
    }

    protected Boolean esVisible(By locator){
        return this.driver.findElement(locator).isDisplayed();
    }

    protected void click(By locator){
        esperarVisible(locator);
        esperarClickear(locator).click();
    }

    protected void escribir(By locator, String texto){
        esperarVisible(locator).clear();
        esperarVisible(locator).sendKeys(texto);
    }

    protected String obtenerTexto(By locator){
        return esperarVisible(locator).getText();
    }
}
