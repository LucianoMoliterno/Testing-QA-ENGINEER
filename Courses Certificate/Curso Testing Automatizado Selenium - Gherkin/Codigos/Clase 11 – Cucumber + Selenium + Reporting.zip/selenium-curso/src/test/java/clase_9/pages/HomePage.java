package clase_9.pages;

import clase_9.base.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class HomePage extends BasePage {

    public By carritoBtn = By.xpath("//a[@class='shopping_cart_link']");


    public HomePage(WebDriver driver){
        super(driver);
    }


    public boolean esVisibleElCarrito(){
        return esVisible(this.carritoBtn);
    }

}
