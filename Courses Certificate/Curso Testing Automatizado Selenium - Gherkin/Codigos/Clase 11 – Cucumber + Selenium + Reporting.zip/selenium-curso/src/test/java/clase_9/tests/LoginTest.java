package clase_9.tests;

import clase_9.base.TestBase;
import clase_9.pages.HomePage;
import clase_9.pages.LoginPage;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class LoginTest extends TestBase {

    @Test
    public void loginCorrecto(){
        // Patron AAA
        //1- Precondiciones
        LoginPage loginPage = new LoginPage(driver);
        HomePage homePage = new HomePage(driver);

        //2- Acciones
        // loginPage.ingresarUsuario("standard_user");
        // loginPage.ingresarPassword("secret_sauce");
        loginPage.hacerLogin("standard_user", "secret_sauce");

        //3- Asserts
        Assertions.assertTrue(
                homePage.esVisibleElCarrito(),
                "El carrito no es visible"
        );
    }

    @Test
    public void loginIncorrectoDebeMostrarError(){
        // Patron AAA
        //1- Precondiciones
        LoginPage loginPage = new LoginPage(driver);
        HomePage homePage = new HomePage(driver);

        //2- Acciones
        // loginPage.ingresarUsuario("standard_user");
        // loginPage.ingresarPassword("secret_sauce");
        loginPage.hacerLogin("standard_user", "132456");

        //3- Asserts
        Assertions.assertEquals(
                loginPage.obtenerMensajeError(),
                "Epic sadface: Username and password do not match any user in this service",
                "El mensaje de error no es el correcto/esperado"
        );
    }
}
