package clase_11.stepsdefinitions;


import clase_11.pages.LoginPage;
import clase_11.pages.HomePage;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class LoginSteps  {

    LoginPage loginPage;
    HomePage homePage;

    protected WebDriver driver; //driver = null;

    @Before
    public void setup(){
        //Configuracion del navegador
        WebDriverManager.firefoxdriver().setup();

        //Creacion del driver
        driver = new FirefoxDriver();

        //Indicamos que se maximize la ventana del navegador
        driver.manage().window().maximize();
    }

    @After
    public void tearDown(){
        // Realizamos la validacion por si no se pudo ejecutar correctamente
        //driver = new FirefoxDriver();
        if(driver != null){
            //Cierra el navegador del finalizar la ejecucion del test
            driver.quit();
        }
    }



    @Given("el usuario se encuentra en la pagina de login")
    public void el_usuario_se_encuentra_en_la_pagina_de_login(){
        //Logica necesaria
        //1- Vamos a la pagina de login
        driver.get("https://www.saucedemo.com/");

        //2- Creamos las instancias de las pages que necesitaremos
        loginPage = new LoginPage(driver);
        homePage = new HomePage(driver);
    }

    @When("ingresa usuario {string} y contrasena {string}")
    public void ingresa_usuario_y_contrasena(String userName, String userPass) {
        loginPage.hacerLogin(userName, userPass);
    }

    @Then("deberia acceder a la pagina principal")
    public void deberia_acceder_a_la_pagina_principal() {
        Assertions.assertTrue(
                homePage.esVisibleElCarrito(),
                "El carrito no es visible"
        );
    }

    @Then("deberia ver un mensaje de error {string}")
    public void deberia_ver_un_mensaje_de_error(String messageError) {
        Assertions.assertEquals(
                messageError,
                loginPage.obtenerMensajeError(),
                "El mensaje de error no es el correcto/esperado"
        );
    }
}