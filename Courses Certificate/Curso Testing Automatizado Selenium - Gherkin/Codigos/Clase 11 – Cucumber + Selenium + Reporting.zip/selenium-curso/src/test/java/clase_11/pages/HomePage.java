package clase_11.pages;

import clase_11.base.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class HomePage extends BasePage {

    public By carritoBtn = By.xpath("//a[@class='shopping_cart_link']");


    public HomePage(WebDriver driver){
        super(driver);
    }


    public boolean esVisibleElCarrito(){
        return esVisible(this.carritoBtn);
    }

}
