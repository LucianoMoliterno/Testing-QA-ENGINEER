Feature: Login de usuario

  Background:
    Given el usuario se encuentra en la pagina de login

  Scenario: Login exitoso
    When ingresa usuario "standard_user" y contrasena "secret_sauce"
    Then deberia acceder a la pagina principal

    Scenario: Login fallido con usuario bloqueado
      When ingresa usuario "locked_out_user" y contrasena "secret_sauce"
      Then deberia ver un mensaje de error "Epic sadface: Sorry, this user has been locked out."