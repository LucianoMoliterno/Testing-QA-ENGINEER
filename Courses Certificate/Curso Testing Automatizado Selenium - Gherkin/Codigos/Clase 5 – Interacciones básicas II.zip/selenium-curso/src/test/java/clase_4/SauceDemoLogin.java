package clase_4;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class SauceDemoLogin {

    public static void main(String[] args) throws InterruptedException {
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();

        driver.get("https://www.saucedemo.com/");


        //Elementos web
        // WebElement -> Clase que nos permite manipular un elemento web
        // .findElement -> Metodo para que el driver busque el elemento web por un localizador
        // By.*(localizador) -> Localizador del elemento web
        WebElement txtUserName = driver.findElement(
                By.id("user-name")
        );

        //*[@id="user-name"]
        //input[@id='user-name']

        WebElement txtPassword = driver.findElement(
                By.name("password")
        );
        WebElement btnLogin = driver.findElement(
                By.xpath("//input[@id='login-button']")
        );

        //Interacciones
        // .sendKeys -> ingresa texto en un input
        // .click -> clickea un elemento web
        txtUserName.sendKeys("standard_user");
        txtPassword.sendKeys("secret_sauce");
        Thread.sleep(5000); //Ayuda a frenar la ejecucion. NO USAR.
        btnLogin.click();
        Thread.sleep(10000); //Ayuda a frenar la ejecucion. NO USAR.


        driver.quit();
    }
}
