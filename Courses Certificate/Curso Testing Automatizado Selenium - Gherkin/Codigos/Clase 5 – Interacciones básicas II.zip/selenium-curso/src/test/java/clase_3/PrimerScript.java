package clase_3;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class PrimerScript {

    public static void main(String[] args) {
        //Configuramos el webdriver
        System.setProperty("webdriver.chrome.driver",
                            "C:\\drivers\\chromedriver.exe");

        // Creamos una instancia para controlar el navegador
        WebDriver driver = new ChromeDriver();

        // Maximizamos el navegador
        driver.manage().window().maximize();

        // Indicamos a que pagina queremos que navege
        driver.get("https://www.google.com/");

        // Frena la ejecucion por "x" milisegundos
        // MALA PRACTICA - NO USAR
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        // Muestra por consola el titulo de la pagina
        System.out.println("Titulo: " + driver.getTitle());

        //Cierra el navegador
        driver.quit();
    }
}
