package clase_5;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class IFrames {

    public static void main(String[] args) {
        //Configuracion de Navegador
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();

        driver.get("https://www.hyrtutorials.com/p/frames-practice.html");


        //Indicamos al driver que se enfoque en el frame
        driver.switchTo().frame("frm2");

        //Buscamos los elementos webs
        WebElement firstName = driver.findElement(By.id("firstName"));

        //Ingresamos el nombre en el frame elegido
        firstName.sendKeys("Nelson");

        // Volvemos a la pagina principal
        driver.switchTo().defaultContent();

        driver.quit();
    }
}
