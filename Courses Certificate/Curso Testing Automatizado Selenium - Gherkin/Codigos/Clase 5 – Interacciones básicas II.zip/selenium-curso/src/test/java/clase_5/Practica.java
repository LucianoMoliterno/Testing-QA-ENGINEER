package clase_5;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Duration;

public class Practica {

    private static final Logger log = LoggerFactory.getLogger(Practica.class);

    public static void main(String[] args) {
        //Configuracion de Navegador
        WebDriverManager.firefoxdriver().setup();
        WebDriver driver = new FirefoxDriver();

        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(2));

        driver.get("https://www.saucedemo.com/");

        WebElement userName = driver.findElement(By.id("user-name"));
        WebElement userPassword = driver.findElement(By.id("password"));
        WebElement login = driver.findElement(By.id("login-button"));

        userName.sendKeys("performance_glitch_user");
        userPassword.sendKeys("secret_sauce");
        login.click();

        WebElement carrito = driver.findElement(By.id("shopping_cart_container"));
        carrito.click();

        System.out.println("Titulo: " + driver.getTitle());
    }
}
