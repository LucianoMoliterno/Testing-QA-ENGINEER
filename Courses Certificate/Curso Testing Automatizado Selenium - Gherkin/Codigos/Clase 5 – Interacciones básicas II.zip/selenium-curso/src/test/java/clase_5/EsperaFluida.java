package clase_5;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class EsperaFluida {


    public static void main(String[] args) {
        //Configuracion de Navegador
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();

        //Configuracion de waits
        Wait<WebDriver> wait = new FluentWait<>(driver)
                .withTimeout(Duration.ofSeconds(11)) //Duracion total
                .pollingEvery(Duration.ofSeconds(2)) //Cada 2 segundo va a consultar sobre el elemento
                .ignoring(NoSuchElementException.class) //Exceptions que va a estar ignorando en la duracion total
                ;

        // Indicamos la url
        driver.get("https://www.hyrtutorials.com/p/waits-demo.html");

        // Obtenemos los elementos webs con la espera explicita
        WebElement boton = wait.until(
                d -> d.findElement(By.id("btn2"))
        );

        // Realizamos acciones sobre los elementos
        boton.click();

        // NO USAR -> Se reemplaza por esperas (waits)
        /*
        try {
            Thread.sleep(11000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
         */

        WebElement text = wait.until(
                d -> d.findElement(By.xpath("//input[@id='txt2']"))
        );


        System.out.println("Caja de Texto visible?: " + text.isDisplayed());

        driver.quit();
    }
}
