package clase_3;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ScriptPractica {

    public static void main(String[] args) {
        System.setProperty("webdriver.chrome.driver",
                "C:\\drivers\\chromedriver.exe");

        WebDriver driver = new ChromeDriver();

        driver.get("https://www.wikipedia.org");

        System.out.println("Titulo: " + driver.getTitle());
        System.out.println("URL: " + driver.getCurrentUrl());
        System.out.println("Codigo fuente: " + driver.getPageSource());

        driver.quit();
    }
}
