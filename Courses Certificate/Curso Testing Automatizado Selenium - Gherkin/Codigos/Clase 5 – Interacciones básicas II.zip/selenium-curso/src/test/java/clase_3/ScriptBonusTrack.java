package clase_3;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ScriptBonusTrack {

    public static void main(String[] args) {
        //System.setProperty("webdriver.chrome.driver",
        //        "C:\\drivers\\chromedriver.exe");

        // Lo de arriba se reemplaza por lo siguiente
        WebDriverManager.chromedriver().setup();


        WebDriver driver = new ChromeDriver();

        driver.get("https://www.wikipedia.org");

        System.out.println("Titulo: " + driver.getTitle());
        System.out.println("URL: " + driver.getCurrentUrl());
        System.out.println("Codigo fuente: " + driver.getPageSource());

        driver.quit();
    }

}
