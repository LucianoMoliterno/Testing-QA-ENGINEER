package clase_5;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class Alertas {

    public static void main(String[] args) {
        //Configuracion de Navegador
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();

        //Configuracion de waits
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));


        // Indicamos la url
        driver.get("https://the-internet.herokuapp.com/javascript_alerts");


        // Obtenemos los botones de las posibles alertas
        WebElement btn_alert = driver.findElement(By.xpath("//button[@onclick='jsAlert()']"));

        btn_alert.click();

        Alert alert = driver.switchTo().alert();
        System.out.println("Texto de la alerta: " + alert.getText());
        alert.accept();

        driver.quit();
    }
}
