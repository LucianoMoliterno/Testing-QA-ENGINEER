package clase_7;

public class Validador {

    public boolean esMayor(int edad){
        return edad >= 18;
    }

    public boolean emailValido(String email){
        return email.contains("@") && email.contains(".");
    }
}
