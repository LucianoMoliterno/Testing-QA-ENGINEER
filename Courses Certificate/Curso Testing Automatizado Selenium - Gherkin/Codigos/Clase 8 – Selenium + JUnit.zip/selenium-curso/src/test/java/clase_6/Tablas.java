package clase_6;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class Tablas {

    public static void main(String[] args) {
        //Configuracion de Navegador
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();

        driver.get("https://practice.expandtesting.com/tables");

        List<WebElement> filas = driver.findElements(By.id("table1"));

        for (WebElement fila : filas){
            List<WebElement> columnas = fila.findElements(By.tagName("td"));

            String filaCompleta = "";
            for (int i = 0; i < columnas.size(); i++) {
                if(columnas.get(i).getText().contains("Edit")){
                    filaCompleta = filaCompleta + "\n";
                }
                else{
                    filaCompleta = filaCompleta + " | " + columnas.get(i).getText();
                }
            }

            System.out.println(filaCompleta);
        }

        try {
            File captura = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            Files.copy(captura.toPath(), Paths.get("capturas/" + UUID.randomUUID().toString() + ".png"));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }


        driver.quit();
    }
}
