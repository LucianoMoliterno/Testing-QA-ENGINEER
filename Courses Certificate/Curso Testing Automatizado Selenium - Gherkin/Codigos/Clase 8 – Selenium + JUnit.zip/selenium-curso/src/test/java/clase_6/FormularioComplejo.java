package clase_6;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import java.util.*;

public class FormularioComplejo {

    public static void main(String[] args) {
        //Configuracion de Navegador
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();

        driver.get("https://www.selenium.dev/selenium/web/web-form.html");

        inputText(driver);
        checkbox(driver);
        radioButton(driver);
        select(driver);

        driver.quit();
    }

    private static void select(WebDriver driver) {
        WebElement elemento = driver.findElement(
                By.name("my-select")
        );

        // Para manejar una lista desplegable usamos la clase Select
        Select dropdown = new Select(elemento);

        // Seleccionamos un valor de la lista
        dropdown.selectByValue("2");
        dropdown.selectByVisibleText("Two");
        dropdown.selectByIndex(1);


        // Ejemplo para controlar si los elementos estan en la lista desplegable
        List<String> listEsperada = new ArrayList<>();
        listEsperada.add("One");
        listEsperada.add("Two");
        listEsperada.add("Three");

        List<WebElement> opciones = dropdown.getOptions();

        boolean isExists = false;

        for (WebElement o : opciones){

            for (String le : listEsperada){
                if(le.equals(o.getText())){
                    isExists = true;
                    break; // Finaliza el ciclo (bucle)
                }
            }

            if(isExists == true){
                System.out.println("El item " + o.getText() + " se encuentra!!");
            }
            else{
                System.out.println("El item " + o.getText() + " NO se encuentra!!");
            }
        }

    }

    private static void radioButton(WebDriver driver) {
        WebElement radio = driver.findElement(
                By.id("my-radio-2")
        );

        radio.click();
    }

    private static void checkbox(WebDriver driver) {
        WebElement checkbox = driver.findElement(
                By.id("my-check-2")
        );

        // checkbox.isSelected() -> false
        // !checkbox.isSelected() -> !false -> true
        if(!checkbox.isSelected()){
            checkbox.click();
        }
    }

    private static void inputText(WebDriver driver) {
        WebElement textInput = driver.findElement(
                By.id("my-text-id")
        );
        textInput.clear();
        textInput.sendKeys("Texto desde una prueba automatizada");
    }
}
