package clase_8.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class HomePage {

    private WebDriver driver;

    public By carritoBtn = By.xpath("//a[@class='shopping_cart_link']");


    public HomePage(WebDriver driver){
        this.driver = driver;
    }


    public boolean esVisibleElCarrito(){
        return this.driver.findElement(this.carritoBtn).isDisplayed();
    }

}
