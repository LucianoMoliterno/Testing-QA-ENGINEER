package clase_8.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPage {

    private WebDriver driver;

    //Localizadores
    private By userInput = By.id("user-name");
    private By passInput = By.id("password");
    private By loginBtn = By.id("login-button");
    private By messageError = By.xpath("//h3[@data-test='error']");

    //Constructor
    public LoginPage(WebDriver driver){
        this.driver = driver;
    }

    //Acciones
    public void ingresarUsuario(String usuario){
        //Busca el elemento y lo limpia
        driver
                .findElement(this.userInput)
                .clear();
        //Busca el elemento y escribe en el mismo
        driver
                .findElement(this.userInput)
                .sendKeys(usuario);
    }

    public void ingresarPassword(String password){
        //Busca el elemento y lo limpia
        driver
                .findElement(this.passInput)
                .clear();
        //Busca el elemento y escribe en el mismo
        driver
                .findElement(this.passInput)
                .sendKeys(password);
    }

    public void hacerLogin(String nombreUsuario, String password){
        ingresarUsuario(nombreUsuario);
        ingresarPassword(password);

        //Busca el elemento y hace click en él
        driver
                .findElement(this.loginBtn)
                .click();
    }

    public String obtenerMensajeError(){
        return driver.findElement(this.messageError).getText();
    }
}
