package clase_7.pruebasUnitarias;

import clase_7.Validador;
import org.junit.jupiter.api.*;

public class ValidadorTest {

    @BeforeAll
    public static void unaVezAlIniciar(){
        System.out.println("Se ejecuto el @BeforeAll");
    }

    @BeforeEach
    public void porCadaInicioTest(){
        System.out.println("Se ejecuto @BeforeEach");
    }


    @Test
    public void testEdadMayor(){
        //Aplicamos el patron AAA

        // Preparamos todo lo necesario para la prueba
        Validador validador = new Validador();

        // Ejecutamos el metodo a testear
        boolean res = validador.esMayor(18);

        // Realizamos las verificaciones
        //Assertions.assertEquals(true, res, "La edad 18 no es mayor");
        Assertions.assertTrue(res, "La edad 18 no es mayor");
    }

    @Test
    public void testEdadMenor(){
        //Aplicamos el patron AAA

        // Preparamos todo lo necesario para la prueba
        Validador validador = new Validador();

        // Ejecutamos el metodo a testear
        boolean res = validador.esMayor(10);

        // Realizamos las verificaciones
        //Assertions.assertEquals(false, res, "La edad 10 no es mayor");
        Assertions.assertFalse(res, "La edad 10 no es menor");
    }

    @Test
    public void tesEmailCorrecto(){
        //Aplicamos el patron AAA

        // Preparamos todo lo necesario para la prueba
        Validador validador = new Validador();

        // Ejecutamos el metodo a testear
        boolean res = validador.emailValido("nelson@example.com");

        // Realizamos las verificaciones
        //Assertions.assertEquals(true, res, "El email nelson@example.com no es valido");
        Assertions.assertTrue(res, "El email nelson@example.com no es valido");
    }


    @Test
    public void testEmailIncorrectoPorArroba(){
        //Aplicamos el patron AAA

        // Preparamos todo lo necesario para la prueba
        Validador validador = new Validador();

        // Ejecutamos el metodo a testear
        boolean res = validador.emailValido("nelsonexample.com");

        // Realizamos las verificaciones
        //Assertions.assertEquals(false, res, "El email nelsonexample.com es valido");
        Assertions.assertFalse(res, "El email nelsonexample.com es valido");
    }

    @Test
    public void testEmailIncorrectoPorPunto(){
        //Aplicamos el patron AAA

        // Preparamos todo lo necesario para la prueba
        Validador validador = new Validador();

        // Ejecutamos el metodo a testear
        boolean res = validador.emailValido("nelson@examplecom");

        // Realizamos las verificaciones
        //Assertions.assertEquals(false, res, "El email nelson@examplecom es valido sin el punto");
        Assertions.assertFalse(res, "El email nelson@examplecom es valido sin el punto");
    }

    @AfterEach
    public void porCadaFinTest(){
        System.out.println("Se ejecuto @AfterEach");
    }

    @AfterAll
    public static void unaVezAlFinalizar(){
        System.out.println("Se ejecuto el @AfterAll");
    }

}
