package clase_8.base;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class TestBase {
    //public - private - protected
    protected WebDriver driver; //driver = null;

    @BeforeEach
    public void setup(){
        //Configuracion del navegador
        WebDriverManager.firefoxdriver().setup();

        //Creacion del driver
        driver = new FirefoxDriver();

        //Indicamos que se maximize la ventana del navegador
        driver.manage().window().maximize();

        //Indicamos al driver que tiene que ir a la pagina
        driver.get("https://www.saucedemo.com/");
    }

    @AfterEach
    public void tearDown(){
        // Realizamos la validacion por si no se pudo ejecutar correctamente
        //driver = new FirefoxDriver();
        if(driver != null){
            //Cierra el navegador del finalizar la ejecucion del test
            driver.quit();
        }
    }
}
